Using the OpenREM interface and export function
***********************************************


Navigating the OpenREM web interface
====================================

placeholder


Filtering for specific studies
==============================

placeholder

Exporting to csv and xlsx sheets
================================

placeholder
